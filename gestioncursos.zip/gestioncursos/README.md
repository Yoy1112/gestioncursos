# Gestión de Cursos — Spring Boot MVC + Thymeleaf

Actividad académica — Desarrollo Web, Unidad 2.
Ejercicio asignado: **N.° 28 — Curso**.

## Descripción

Aplicación web MVC construida con Spring Boot, Spring MVC, Spring Data JPA y
Thymeleaf. Renderiza las vistas del lado del servidor (no es una API REST).
Maneja dos entidades: `Usuario` (id, clave, nombre, rol) y `Curso` (entidad de
negocio del ejercicio 28), con CRUD completo, login, reportes parametrizados
y recuperación de clave.

## Tecnologías

- Java 17
- Spring Boot 3.2.5 (Spring MVC, Spring Data JPA, Thymeleaf)
- Maven
- Base de datos H2 (archivo local, motor relacional embebido)

## Estructura del proyecto

```
src/main/java/com/estudiante/gestioncursos/
 ├── entity/        -> Usuario, Curso
 ├── repository/     -> UsuarioRepository, CursoRepository (Spring Data JPA)
 ├── service/        -> UsuarioService, CursoService (lógica de negocio)
 ├── controller/      -> LoginController, HomeController, UsuarioController, CursoController
 └── config/         -> LoginInterceptor, WebConfig (control de acceso por sesión)
src/main/resources/
 ├── templates/       -> vistas Thymeleaf (.html)
 └── application.properties
database/script_creacion_bd.sql -> script de referencia del esquema de BD
```

## Flujo MVC

navegador → Controller → Service → Repository → base de datos → Service →
Controller/Model → Thymeleaf → HTML → navegador.

## Cómo ejecutar el proyecto

### Opción 1: NetBeans
1. Abrir NetBeans → File → Open Project → seleccionar la carpeta `gestioncursos`.
2. NetBeans detecta el `pom.xml` y descarga las dependencias de Maven automáticamente
   (requiere conexión a internet la primera vez).
3. Clic derecho sobre el proyecto → Run.
4. Abrir el navegador en: http://localhost:8080

### Opción 2: línea de comandos
```bash
mvn spring-boot:run
```

## Usuario por defecto

Al arrancar por primera vez, la aplicación crea automáticamente un usuario
administrador si la tabla `usuarios` está vacía:

- **Usuario:** admin
- **Clave:** admin123

## Base de datos

Se usa H2 en modo archivo (`./data/gestioncursos`), por lo que no es necesario
instalar ni configurar un motor de base de datos externo. El archivo de datos
se crea automáticamente en la carpeta `data/` del proyecto al arrancar.

Consola web de H2 (para inspeccionar las tablas manualmente):
http://localhost:8080/h2-console
- JDBC URL: `jdbc:h2:file:./data/gestioncursos`
- Usuario: `sa`
- Clave: (vacía)

El esquema también está documentado en `database/script_creacion_bd.sql`.

## Funcionalidades implementadas

- [x] CRUD completo de Usuario
- [x] CRUD completo de Curso
- [x] Login con control de acceso por sesión (interceptor)
- [x] 2 reportes parametrizados de Usuario (por rol, por nombre)
- [x] 3 reportes parametrizados de Curso (por nivel, por modalidad, por precio máximo)
- [ ] Recuperación de clave por correo — **pendiente de conectar el envío real de
      email** (JavaMailSender). El flujo de pantallas ya está armado en
      `/recuperar-clave`; falta integrar el envío efectivo del correo.
- [ ] Despliegue en servicio de Internet — pendiente.

## Variables de entorno (para despliegue)

- `PORT`: puerto en el que corre el servidor (por defecto 8080; algunos
  servicios de hosting como Render lo asignan automáticamente).

## Autor

[Completar: código y nombre completo del estudiante]
