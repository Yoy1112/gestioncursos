-- =========================================================
-- Script de creacion de base de datos - Gestion de Cursos
-- Motor: H2 (compatible con sintaxis SQL estandar)
-- =========================================================
-- NOTA: Esta aplicacion usa spring.jpa.hibernate.ddl-auto=update,
-- por lo que Hibernate crea y actualiza estas tablas automaticamente
-- al arrancar la aplicacion. Este script se incluye como referencia
-- documental del esquema y como respaldo por si se requiere crear
-- las tablas manualmente en otro motor de base de datos.

CREATE TABLE IF NOT EXISTS usuarios (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    clave VARCHAR(255) NOT NULL,
    nombre VARCHAR(255) NOT NULL,
    rol VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS cursos (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    precio DOUBLE,
    horas INT,
    nivel VARCHAR(50),
    profesor VARCHAR(255),
    institucion VARCHAR(255),
    fecha_inscripcion_inicio DATE,
    fecha_inscripcion_fin DATE,
    fecha_inicio DATE,
    fecha_cierre DATE,
    num_alumnos INT,
    modalidad VARCHAR(50),
    descripcion VARCHAR(1000)
);

-- Datos iniciales (opcional). La aplicacion tambien crea un usuario
-- administrador automaticamente en el primer arranque si la tabla
-- usuarios esta vacia (ver GestionCursosApplication.java).
INSERT INTO usuarios (clave, nombre, rol) VALUES ('admin123', 'admin', 'ADMIN');

INSERT INTO cursos (nombre, precio, horas, nivel, profesor, institucion,
    fecha_inscripcion_inicio, fecha_inscripcion_fin, fecha_inicio, fecha_cierre,
    num_alumnos, modalidad, descripcion)
VALUES ('Introduccion a Java', 150000, 40, 'Basico', 'Carlos Perez', 'Instituto Tech',
    '2026-09-01', '2026-09-15', '2026-09-20', '2026-11-20',
    25, 'Virtual', 'Curso introductorio de programacion en Java.');
